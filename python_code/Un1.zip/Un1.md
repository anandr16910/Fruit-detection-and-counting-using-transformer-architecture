```python
import os
import glob
import re
import sys

def parse_roboflow_filenames(data_dir):
    # 1. Targets: The fruits you specifically asked for (plus common variations)
    # We use stems to catch "strawberries" vs "strawberry"
    targets = {
        'avocado': 0, 
        'orange': 0, 
        'kiwi': 0, 
        'banana': 0, 
        'blueberry': 0, 
        'cherry': 0,
        'apple': 0,
        'strawberry': 0,
        'strawberries': 0, # Roboflow often keeps plural
        'mango': 0,
        'grapes': 0
    }

    # 2. Get all images recursively
    print(f"Scanning directory: {data_dir}")
    # Grab jpg, jpeg, png. Case insensitive is handled by glob in newer python, 
    # but we'll stick to standard extensions for safety.
    extensions = ['*.jpg', '*.jpeg', '*.png']
    image_files = []
    for ext in extensions:
        image_files.extend(glob.glob(os.path.join(data_dir, "**", ext), recursive=True))

    print(f"[INFO] Found {len(image_files)} total image files. Analyzing names...\n")

    found_files = []

    for filepath in image_files:
        filename = os.path.basename(filepath)
        
        # --- PARSING LOGIC FOR ROBOFLOW ---
        # Pattern: Name_ext.rf.hash.jpg
        # Example: SpringStrawberries_png.rf.226...
        
        # 1. Split by ".rf." to strip the hash
        if ".rf." in filename:
            name_part = filename.split(".rf.")[0]
        else:
            name_part = filename

        # 2. Remove the extension part attached to the name (e.g. "_png", "_jpg")
        # Regex: remove _jpg or _png at the end of the name_part
        name_part = re.sub(r'_(jpg|png|jpeg)$', '', name_part, flags=re.IGNORECASE)

        # 3. Clean up separators to find hidden words
        # "weetheart-Cherry-tree" -> "weetheart cherry tree"
        # "SpringStrawberries" -> "springstrawberries"
        clean_name = name_part.lower().replace('-', ' ').replace('_', ' ')

        # 4. Check for targets
        matched = False
        for fruit in targets.keys():
            if fruit in clean_name:
                targets[fruit] += 1
                matched = True
                
        # (Optional) Save match for debugging
        if matched:
            found_files.append((clean_name, filename))

    # --- OUTPUT RESULTS ---
    print("="*40)
    print("FRUIT COUNT (Based on Filenames)")
    print("="*40)
    
    total_found = 0
    for fruit, count in targets.items():
        if count > 0:
            print(f"✅ {fruit.capitalize()}: {count} files")
            total_found += count
        else:
            print(f"❌ {fruit.capitalize()}: 0 files")

    print("-" * 40)
    if total_found == 0:
        print("[WARNING] Still found 0 matches. Let's look at the cleaned names to see why.")
        print("First 10 Cleaned Names (Debugging):")
        for f in image_files[:10]:
            raw = os.path.basename(f)
            # Re-run clean logic just for display
            if ".rf." in raw: part = raw.split(".rf.")[0]
            else: part = raw
            clean = re.sub(r'_(jpg|png|jpeg)$', '', part, flags=re.IGNORECASE).lower()
            print(f"  Raw: {raw}  ->  Cleaned: '{clean}'")
    else:
        print(f"[SUCCESS] identified {total_found} fruit images.")

def main():
    current_dir = os.getcwd()
    data_dir = os.path.join(current_dir, "FruitDetectionDataset")
    
    if not os.path.isdir(data_dir):
        print(f"Folder not found: {data_dir}")
        sys.exit(1)

    parse_roboflow_filenames(data_dir)

if __name__ == "__main__":
    main()
```

    Scanning directory: /Users/anandrajgopalan/Documents/ARM_AI/test_apps/FruitDetectionDataset
    [INFO] Found 4295 total image files. Analyzing names...
    
    ========================================
    FRUIT COUNT (Based on Filenames)
    ========================================
    ❌ Avocado: 0 files
    ❌ Orange: 0 files
    ✅ Kiwi: 56 files
    ❌ Banana: 0 files
    ✅ Blueberry: 23 files
    ✅ Cherry: 48 files
    ✅ Apple: 34 files
    ✅ Strawberry: 6 files
    ✅ Strawberries: 9 files
    ❌ Mango: 0 files
    ❌ Grapes: 0 files
    ----------------------------------------
    [SUCCESS] identified 176 fruit images.



```python
import os
import glob
import re
from collections import Counter

def audit_unknown_filenames(data_dir):
    # Known fruits to ignore (we already found these)
    known_fruits = ['kiwi', 'blueberry', 'cherry', 'apple', 'strawberry', 'strawberries']
    
    print(f"Scanning: {data_dir}")
    image_files = []
    for ext in ['*.jpg', '*.jpeg', '*.png']:
        image_files.extend(glob.glob(os.path.join(data_dir, "**", ext), recursive=True))

    print(f"[INFO] Analyzing {len(image_files)} filenames...")

    unknown_names = []
    
    for filepath in image_files:
        filename = os.path.basename(filepath)
        
        # 1. Clean the Roboflow name
        # Remove hash: "a_jpg.rf.12345.jpg" -> "a_jpg"
        if ".rf." in filename:
            name_part = filename.split(".rf.")[0]
        else:
            name_part = filename

        # Remove extension suffix: "a_jpg" -> "a"
        clean_name = re.sub(r'_(jpg|png|jpeg)$', '', name_part, flags=re.IGNORECASE).lower()
        clean_name = clean_name.replace('-', ' ').replace('_', ' ')

        # 2. Check if it is a known fruit
        is_known = False
        for k in known_fruits:
            if k in clean_name:
                is_known = True
                break
        
        # 3. If NOT known, record it
        if not is_known:
            unknown_names.append(clean_name)

    # --- REPORT ---
    print("\n" + "="*40)
    print("TOP 20 MOST COMMON 'MYSTERY' NAMES")
    print("="*40)
    
    counts = Counter(unknown_names)
    
    if not counts:
        print("Amazing! All files matched known fruits (Unlikely).")
    else:
        for name, count in counts.most_common(20):
            print(f"Name: '{name}' \t Count: {count}")
            
    print("-" * 40)
    print("INTERPRETATION GUIDE:")
    print("If you see 'a': Check if it contains Apples or Avocados.")
    print("If you see 'b': Check if it contains Bananas or Blueberries.")
    print("If you see 'img': These are generic names (unrecoverable without XML).")

if __name__ == "__main__":
    data_dir = os.path.join(os.getcwd(), "FruitDetectionDataset")
    if os.path.isdir(data_dir):
        audit_unknown_filenames(data_dir)
    else:
        print("Dataset folder not found.")
```

    Scanning: /Users/anandrajgopalan/Documents/ARM_AI/test_apps/FruitDetectionDataset
    [INFO] Analyzing 4295 filenames...
    
    ========================================
    TOP 20 MOST COMMON 'MYSTERY' NAMES
    ========================================
    Name: 'unnamed' 	 Count: 4
    Name: 'unnamed  1 ' 	 Count: 3
    Name: 'images  1 ' 	 Count: 3
    Name: 'images' 	 Count: 3
    Name: 'unnamed  2 ' 	 Count: 3
    Name: 'images  3 ' 	 Count: 3
    Name: 'images  2 ' 	 Count: 3
    Name: 'thumb' 	 Count: 2
    Name: 'maxresdefault' 	 Count: 2
    Name: '760 970' 	 Count: 2
    Name: '1 500x500' 	 Count: 2
    Name: 'images  5 ' 	 Count: 2
    Name: 'image' 	 Count: 2
    Name: 'images  4 ' 	 Count: 2
    Name: '7b9dfab15' 	 Count: 1
    Name: 'e3471d3c2' 	 Count: 1
    Name: '1498434440204' 	 Count: 1
    Name: 'fa060c1f8' 	 Count: 1
    Name: 'istockphoto 171314137 612x612  1 ' 	 Count: 1
    Name: '0877092cc' 	 Count: 1
    ----------------------------------------
    INTERPRETATION GUIDE:
    If you see 'a': Check if it contains Apples or Avocados.
    If you see 'b': Check if it contains Bananas or Blueberries.
    If you see 'img': These are generic names (unrecoverable without XML).



```python
import os
import glob
import json
import sys

def scan_json_annotations(data_dir):
    print(f"--- Scanning JSON files in: {data_dir} ---")
    
    # 1. Find all JSON files recursively
    json_files = glob.glob(os.path.join(data_dir, "**", "*.json"), recursive=True)
    
    if not json_files:
        print("[ERROR] No JSON files found! Check your path.")
        return

    print(f"[INFO] Found {len(json_files)} JSON files. Reading contents...")

    # 2. Define the fruits we want to track
    target_fruits = {
        'avocado': 0, 'orange': 0, 'kiwi': 0, 'banana': 0, 
        'blueberry': 0, 'cherry': 0, 'apple': 0, 
        'strawberry': 0, 'mango': 0, 'grapes': 0
    }
    
    # Store all unique labels found (in case names are slightly different, e.g., "fresh_orange")
    all_found_labels = set()

    # 3. Iterate through every single JSON file
    for j_path in json_files:
        try:
            with open(j_path, 'r') as f:
                data = json.load(f)
                
            found_in_file = []
            
            # --- PARSING LOGIC ---
            # Roboflow JSONs usually have an "objects" list or "shapes" list
            objects = []
            if isinstance(data, dict):
                objects = data.get('objects', []) or data.get('shapes', []) or data.get('annotations', [])
            elif isinstance(data, list):
                # Sometimes CreateML format is just a list
                objects = data
            
            # Extract labels from the objects
            for obj in objects:
                # The label might be under 'label', 'name', or 'category'
                label = obj.get('label') or obj.get('name') or obj.get('category')
                
                if label:
                    label_clean = label.lower().strip()
                    found_in_file.append(label_clean)
                    all_found_labels.add(label_clean)
            
            # Count matches for our targets
            # We use set() to avoid counting "3 oranges" in one picture as 3 separate files
            unique_fruits_in_image = set(found_in_file)
            for fruit in unique_fruits_in_image:
                # Check for partial match (e.g. "orange" matches "blood orange")
                for target in target_fruits:
                    if target in fruit:
                        target_fruits[target] += 1
                        
        except Exception as e:
            # Skip corrupted files
            continue

    # 4. Print Results
    print("\n" + "="*40)
    print("FRUIT INVENTORY (From JSON Contents)")
    print("="*40)
    
    total_found = 0
    for fruit, count in target_fruits.items():
        if count > 0:
            print(f"✅ {fruit.capitalize()}: {count} images")
            total_found += count
        else:
            print(f"❌ {fruit.capitalize()}: 0 images")
            
    print("-" * 40)
    print(f"Total images with identified fruits: {total_found}")
    
    print("\n" + "="*40)
    print("ALL RAW LABELS FOUND IN DATASET")
    print("(Check this list for names like 'fresh_orange' or 'fruit_avocado')")
    print("="*40)
    print(sorted(list(all_found_labels)))

def main():
    current_dir = os.getcwd()
    data_dir = os.path.join(current_dir, "FruitDetectionDataset")
    
    if not os.path.isdir(data_dir):
        print(f"Dataset folder not found at: {data_dir}")
        sys.exit(1)
        
    scan_json_annotations(data_dir)

if __name__ == "__main__":
    main()
```

    --- Scanning JSON files in: /Users/anandrajgopalan/Documents/ARM_AI/test_apps/FruitDetectionDataset ---
    [INFO] Found 4296 JSON files. Reading contents...
    
    ========================================
    FRUIT INVENTORY (From JSON Contents)
    ========================================
    ❌ Avocado: 0 images
    ❌ Orange: 0 images
    ❌ Kiwi: 0 images
    ❌ Banana: 0 images
    ❌ Blueberry: 0 images
    ❌ Cherry: 0 images
    ❌ Apple: 0 images
    ❌ Strawberry: 0 images
    ❌ Mango: 0 images
    ❌ Grapes: 0 images
    ----------------------------------------
    Total images with identified fruits: 0
    
    ========================================
    ALL RAW LABELS FOUND IN DATASET
    (Check this list for names like 'fresh_orange' or 'fruit_avocado')
    ========================================
    []



```python
import os
import glob
import json
import sys

def scan_json_annotations_fixed(data_dir):
    print(f"--- Scanning JSON files in: {data_dir} ---")
    
    # 1. Find all JSON files recursively
    json_files = glob.glob(os.path.join(data_dir, "**", "*.json"), recursive=True)
    
    if not json_files:
        print("[ERROR] No JSON files found! Check your path.")
        return

    print(f"[INFO] Found {len(json_files)} JSON files. Reading contents...")

    # 2. Track counts
    # We want to find EVERYTHING first to see what names exist
    all_class_counts = {}

    # 3. Iterate through every single JSON file
    for j_path in json_files:
        try:
            with open(j_path, 'r') as f:
                data = json.load(f)
            
            # --- PARSING LOGIC (FIXED) ---
            objects = []
            
            # Handle different JSON structures
            if isinstance(data, dict):
                objects = data.get('objects', []) or data.get('shapes', [])
            elif isinstance(data, list):
                objects = data
            
            # Extract labels
            found_in_this_image = set()
            
            for obj in objects:
                # <--- THE FIX: Look for 'classTitle' first! --->
                label = obj.get('classTitle') or obj.get('label') or obj.get('name')
                
                if label:
                    label_clean = label.lower().strip()
                    found_in_this_image.add(label_clean)
            
            # Update global counts (count 1 image per class)
            for label in found_in_this_image:
                if label in all_class_counts:
                    all_class_counts[label] += 1
                else:
                    all_class_counts[label] = 1
                        
        except Exception:
            continue

    # 4. Print Results
    print("\n" + "="*40)
    print("FINAL FRUIT INVENTORY")
    print("="*40)
    
    # Sort by count (descending)
    sorted_classes = sorted(all_class_counts.items(), key=lambda x: x[1], reverse=True)
    
    if not sorted_classes:
        print("[ERROR] JSONs found, but no 'classTitle' or 'label' keys found inside them.")
    else:
        for name, count in sorted_classes:
            print(f"📁 {name.ljust(20)} : {count} images")

    print("-" * 40)
    print(f"Total unique classes found: {len(sorted_classes)}")

def main():
    current_dir = os.getcwd()
    data_dir = os.path.join(current_dir, "FruitDetectionDataset")
    
    if not os.path.isdir(data_dir):
        print(f"Dataset folder not found at: {data_dir}")
        sys.exit(1)
        
    scan_json_annotations_fixed(data_dir)

if __name__ == "__main__":
    main()
```

    --- Scanning JSON files in: /Users/anandrajgopalan/Documents/ARM_AI/test_apps/FruitDetectionDataset ---
    [INFO] Found 4296 JSON files. Reading contents...
    
    ========================================
    FINAL FRUIT INVENTORY
    ========================================
    📁 wheat                : 3373 images
    📁 mango                : 170 images
    📁 cherry               : 153 images
    📁 kiwi                 : 125 images
    📁 capsicum             : 122 images
    📁 blueberry            : 78 images
    📁 apple                : 63 images
    📁 rockmelon            : 58 images
    📁 orange               : 57 images
    📁 avocado              : 54 images
    📁 strawberry           : 41 images
    ----------------------------------------
    Total unique classes found: 11



```python
import os
import sys
import glob
import json
import re
import cv2
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict, Counter

from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QMessageBox, QSlider, QVBoxLayout, QListWidget
)
from PyQt5.QtCore import Qt

from ultralytics import YOLO
import logging

# ---------------------------
# 1. Silence Logs
# ---------------------------
logging.getLogger("ultralytics").setLevel(logging.CRITICAL)

# ---------------------------
# 2. YOLO Counter Class
# ---------------------------
class YOLOv5ObjectCounter:
    def __init__(self, model_path="yolov5s.pt", device="mps"):
        # Auto-download YOLOv5s if not present
        self.model = YOLO(model_path)
        self.model.to(device)
        self.device = device

    def _run(self, image_bgr):
        img_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        # verbose=False prevents the spammy printing in console
        results = self.model(
            img_rgb,
            conf=0.1,        # Slightly higher conf to reduce noise
            iou=0.5,
            imgsz=640,
            max_det=300,
            agnostic_nms=True,
            device=self.device,
            verbose=False    
        )
        return results[0]

    def count_objects(self, image_bgr):
        r = self._run(image_bgr)
        return float(len(r.boxes))

    def density_map(self, image_bgr):
        h, w = image_bgr.shape[:2]
        heat = np.zeros((h, w), dtype=np.float32)

        r = self._run(image_bgr)
        if r.boxes is None or len(r.boxes) == 0:
            return heat

        boxes = r.boxes.xyxy.cpu().numpy()
        for x1, y1, x2, y2 in boxes:
            x1, y1, x2, y2 = map(int, [x1, y1, x2, y2])
            x1 = max(0, min(w - 1, x1))
            x2 = max(0, min(w, x2))
            y1 = max(0, min(h - 1, y1))
            y2 = max(0, min(h, y2))
            heat[y1:y2, x1:x2] += 1.0

        if heat.max() > 0:
            heat /= heat.max()
        return heat.astype(np.float32)

# ---------------------------
# 3. GUI Application
# ---------------------------
class FruitSearchApp(QWidget):
    def __init__(self, data_dir):
        super().__init__()
        self.data_dir = data_dir
        
        # This dictionary will store { "avocado": ["path/to/img1.jpg", ...], "orange": [...] }
        self.dataset_index = defaultdict(list)
        self.all_found_classes = Counter()
        
        self.filtered_files = []
        self.counts = []
        self.density_maps = []
        self.current_idx = 0
        
        # Initialize the GUI
        self.init_ui()
        
        # Build the index immediately on startup
        self.index_dataset()

    def init_ui(self):
        self.setWindowTitle("Fruit Search & Count (JSON Linked)")
        self.setGeometry(100, 100, 600, 500)

        self.layout = QVBoxLayout()
        
        self.info_label = QLabel("Initializing dataset... please wait.", self)
        self.layout.addWidget(self.info_label)

        self.search_label = QLabel('Enter fruit name (e.g., "avocado", "orange"):', self)
        self.layout.addWidget(self.search_label)

        self.edit = QLineEdit(self)
        self.layout.addWidget(self.edit)

        self.button = QPushButton("Search", self)
        self.button.clicked.connect(self.search_images)
        self.layout.addWidget(self.button)

        # List widget to show available fruits
        self.list_label = QLabel("Available Classes (Double-click to search):", self)
        self.layout.addWidget(self.list_label)
        
        self.class_list_widget = QListWidget(self)
        self.class_list_widget.itemDoubleClicked.connect(self.on_list_item_clicked)
        self.layout.addWidget(self.class_list_widget)

        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.valueChanged.connect(self.update_image_display)
        self.slider.setMinimum(1)
        self.slider.setEnabled(False)
        self.layout.addWidget(self.slider)

        self.image_idx_label = QLabel("0 images found", self)
        self.layout.addWidget(self.image_idx_label)

        self.setLayout(self.layout)

    def index_dataset(self):
        """
        Scans all JSON files to find class names and links them to images.
        """
        print("--- Indexing Dataset... ---")
        json_files = glob.glob(os.path.join(self.data_dir, "**", "*.json"), recursive=True)
        
        if not json_files:
            self.info_label.setText("Error: No JSON files found in 'ann' folders.")
            return

        valid_images_count = 0
        
        for j_path in json_files:
            try:
                # 1. Parse JSON to get the class name
                with open(j_path, 'r') as f:
                    data = json.load(f)
                
                # Check for 'classTitle' (found in your dataset) or 'label'
                objects = []
                if isinstance(data, dict):
                    objects = data.get('objects', []) or data.get('shapes', [])
                elif isinstance(data, list):
                    objects = data

                found_classes_in_file = set()
                for obj in objects:
                    name = obj.get('classTitle') or obj.get('label') or obj.get('name')
                    if name:
                        found_classes_in_file.add(name.lower().strip())

                if not found_classes_in_file:
                    continue

                # 2. Find the corresponding Image file
                # Strategy: JSON is at .../test/ann/image.jpg.json
                # Image is likely at .../test/img/image.jpg
                
                # Strip .json
                base_name = j_path.replace('.json', '')
                
                # Check 1: Same folder?
                if os.path.exists(base_name):
                    img_path = base_name
                else:
                    # Check 2: Swap 'ann' folder with 'img' folder
                    # Split path components
                    parts = base_name.split(os.sep)
                    if 'ann' in parts:
                        # Replace the last occurrence of 'ann' with 'img'
                        # (A simple string replace might be risky if 'ann' is in the filename, but usually safe for path)
                        possible_img_path = base_name.replace(f'{os.sep}ann{os.sep}', f'{os.sep}img{os.sep}')
                        if os.path.exists(possible_img_path):
                            img_path = possible_img_path
                        else:
                            # Image file missing? Skip.
                            continue
                    else:
                        continue

                # 3. Add to index
                for cls in found_classes_in_file:
                    self.dataset_index[cls].append(img_path)
                    self.all_found_classes[cls] += 1
                
                valid_images_count += 1

            except Exception:
                continue

        # Update GUI
        self.info_label.setText(f"Indexed {valid_images_count} images successfully.")
        
        # Populate List Widget
        self.class_list_widget.clear()
        sorted_classes = sorted(self.all_found_classes.items(), key=lambda x: x[1], reverse=True)
        for cls, count in sorted_classes:
            self.class_list_widget.addItem(f"{cls} ({count} images)")
            
        print(f"Index complete. Found classes: {list(self.all_found_classes.keys())}")

    def on_list_item_clicked(self, item):
        # Extract name from "avocado (54 images)"
        text = item.text()
        fruit_name = text.split(' (')[0]
        self.edit.setText(fruit_name)
        self.search_images()

    def search_images(self):
        query = self.edit.text().lower().strip()
        if not query:
            return

        # Look up in index
        # We allow partial match (e.g. "apple" finds "green apple")
        self.filtered_files = []
        for cls_name, files in self.dataset_index.items():
            if query in cls_name:
                self.filtered_files.extend(files)
        
        # Remove duplicates if any
        self.filtered_files = sorted(list(set(self.filtered_files)))

        if not self.filtered_files:
            QMessageBox.warning(self, "No Results", f"No images found for '{query}'")
            self.image_idx_label.setText("0 images found")
            return

        QMessageBox.information(self, "Found", f"Found {len(self.filtered_files)} images containing '{query}'.")
        
        # Reset slider
        self.slider.setRange(1, len(self.filtered_files))
        self.slider.setValue(1)
        self.slider.setEnabled(True)
        
        # Show montage of first 15
        self.show_montage(self.filtered_files[:15], query)
        
        # Process first image immediately
        self.update_image_display(1)

    def update_image_display(self, idx):
        # 1-based index from slider -> 0-based for list
        i = idx - 1
        if i < 0 or i >= len(self.filtered_files):
            return

        filepath = self.filtered_files[i]
        self.image_idx_label.setText(f"Image {idx} / {len(self.filtered_files)}")

        # Load Image
        img = cv2.imread(filepath)
        if img is None:
            return
            
        # Resize for display speed if huge
        h, w = img.shape[:2]
        if h > 800 or w > 800:
            img = cv2.resize(img, (800, 800), interpolation=cv2.INTER_AREA)

        # Run YOLO
        try:
            # Re-init counter if needed or use a persistent one. 
            # For simplicity, we create one here, but better to keep self.counter in __init__
            counter = YOLOv5ObjectCounter() 
            count = counter.count_objects(img)
            density = counter.density_map(img)
            
            # Create Overlay
            overlay = self.create_overlay(img, density, count)
            
            # Show using Matplotlib
            plt.figure("MainViewer")
            plt.clf()
            plt.imshow(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
            plt.title(f"File: {os.path.basename(filepath)}\nCount: {count:.0f}")
            plt.axis("off")
            plt.draw()
            plt.pause(0.001)
            
        except Exception as e:
            print(f"Error processing image: {e}")

    def create_overlay(self, image, density_map, count):
        # Normalize density to 0-255
        norm_map = cv2.normalize(density_map, None, 0, 255, cv2.NORM_MINMAX).astype("uint8")
        heatmap = cv2.applyColorMap(norm_map, cv2.COLORMAP_JET)
        
        # Blend
        alpha = 0.5
        overlay = cv2.addWeighted(image, 1 - alpha, heatmap, alpha, 0)
        
        # Text
        text = f"Count: {count:.0f}"
        cv2.putText(overlay, text, (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 
                    1.5, (255, 255, 255), 3)
        return overlay

    def show_montage(self, files, pattern):
        images = []
        for f in files:
            img = cv2.imread(f)
            if img is not None:
                img = cv2.resize(img, (200, 200))
                images.append(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        
        if not images:
            return

        # Grid logic
        n = len(images)
        cols = 5
        rows = (n // cols) + 1
        
        plt.figure("Search Results Montage")
        for i, img in enumerate(images):
            plt.subplot(rows, cols, i+1)
            plt.imshow(img)
            plt.axis('off')
        plt.tight_layout()
        plt.show(block=False)

def main():
    # 1. Setup Data Directory
    current_dir = os.getcwd()
    data_dir = os.path.join(current_dir, "FruitDetectionDataset")
    
    if not os.path.isdir(data_dir):
        print(f"Error: Dataset not found at {data_dir}")
        sys.exit(1)

    app = QApplication(sys.argv)
    
    # 2. Launch App
    viewer = FruitSearchApp(data_dir)
    viewer.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
```

    --- Indexing Dataset... ---
    Index complete. Found classes: ['wheat', 'cherry', 'apple', 'strawberry', 'blueberry', 'kiwi', 'mango', 'capsicum', 'avocado', 'rockmelon', 'orange']



    
![png](output_4_1.png)
    



    
![png](output_4_2.png)
    



    
![png](output_4_3.png)
    



    
![png](output_4_4.png)
    



    
![png](output_4_5.png)
    



    
![png](output_4_6.png)
    



    
![png](output_4_7.png)
    



    
![png](output_4_8.png)
    



    
![png](output_4_9.png)
    



    
![png](output_4_10.png)
    



    
![png](output_4_11.png)
    



    
![png](output_4_12.png)
    



    
![png](output_4_13.png)
    



    
![png](output_4_14.png)
    



    
![png](output_4_15.png)
    



    
![png](output_4_16.png)
    



    
![png](output_4_17.png)
    



    
![png](output_4_18.png)
    



    
![png](output_4_19.png)
    



```python
import os
import sys
import glob
import json
import re
import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from collections import defaultdict, Counter

from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QMessageBox, QSlider, QVBoxLayout, QListWidget, QDialog
)
from PyQt5.QtCore import Qt

from ultralytics import YOLO
import logging

# ---------------------------
# 1. Silence Logs
# ---------------------------
logging.getLogger("ultralytics").setLevel(logging.CRITICAL)

# ---------------------------
# 2. YOLO Counter Class
# ---------------------------
class YOLOv5ObjectCounter:
    def __init__(self, model_path="yolov5s.pt", device="mps"):
        # Auto-download YOLOv5s if not present
        self.model = YOLO(model_path)
        self.model.to(device)
        self.device = device

    def _run(self, image_bgr):
        img_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        results = self.model(
            img_rgb,
            conf=0.1,        
            iou=0.5,
            imgsz=640,
            max_det=300,
            agnostic_nms=True,
            device=self.device,
            verbose=False    
        )
        return results[0]

    def count_objects(self, image_bgr):
        r = self._run(image_bgr)
        return float(len(r.boxes))

    def density_map(self, image_bgr):
        h, w = image_bgr.shape[:2]
        heat = np.zeros((h, w), dtype=np.float32)

        r = self._run(image_bgr)
        if r.boxes is None or len(r.boxes) == 0:
            return heat

        boxes = r.boxes.xyxy.cpu().numpy()
        for x1, y1, x2, y2 in boxes:
            x1, y1, x2, y2 = map(int, [x1, y1, x2, y2])
            x1 = max(0, min(w - 1, x1))
            x2 = max(0, min(w, x2))
            y1 = max(0, min(h - 1, y1))
            y2 = max(0, min(h, y2))
            heat[y1:y2, x1:x2] += 1.0

        if heat.max() > 0:
            heat /= heat.max()
        return heat.astype(np.float32)

# ---------------------------
# 3. Custom Dialog for Montage
# ---------------------------
class MontageDialog(QDialog):
    def __init__(self, images, query, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Montage Results for '{query}'")
        self.resize(1000, 800) 
        
        # Layout
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Matplotlib Figure and Canvas
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)
        
        # Plotting
        self.plot_images(images)

    def plot_images(self, images):
        self.figure.clear()
        
        n = len(images)
        if n == 0:
            return

        # Calculate grid (5 columns fixed)
        cols = 5
        rows = int(np.ceil(n / cols))
        
        for i, img in enumerate(images):
            # Add subplot
            ax = self.figure.add_subplot(rows, cols, i+1)
            ax.imshow(img)
            ax.axis('off')
        
        self.figure.tight_layout()
        self.canvas.draw()

# ---------------------------
# 4. Main GUI Application
# ---------------------------
class FruitSearchApp(QWidget):
    def __init__(self, data_dir):
        super().__init__()
        self.data_dir = data_dir
        
        self.dataset_index = defaultdict(list)
        self.all_found_classes = Counter()
        
        self.filtered_files = []
        self.counts = []
        self.density_maps = []
        self.current_idx = 0
        
        # Keep a reference to the dialog window so it doesn't close immediately
        self.montage_window = None
        
        self.init_ui()
        self.index_dataset()

    def init_ui(self):
        self.setWindowTitle("Fruit Search & Count (JSON Linked)")
        self.setGeometry(100, 100, 600, 500)

        self.layout = QVBoxLayout()
        
        self.info_label = QLabel("Initializing dataset... please wait.", self)
        self.layout.addWidget(self.info_label)

        self.search_label = QLabel('Enter fruit name (e.g., "avocado", "orange"):', self)
        self.layout.addWidget(self.search_label)

        self.edit = QLineEdit(self)
        self.layout.addWidget(self.edit)

        self.button = QPushButton("Search", self)
        self.button.clicked.connect(self.search_images)
        self.layout.addWidget(self.button)

        self.list_label = QLabel("Available Classes (Double-click to search):", self)
        self.layout.addWidget(self.list_label)
        
        self.class_list_widget = QListWidget(self)
        self.class_list_widget.itemDoubleClicked.connect(self.on_list_item_clicked)
        self.layout.addWidget(self.class_list_widget)

        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.valueChanged.connect(self.update_image_display)
        self.slider.setMinimum(1)
        self.slider.setEnabled(False)
        self.layout.addWidget(self.slider)

        self.image_idx_label = QLabel("0 images found", self)
        self.layout.addWidget(self.image_idx_label)

        self.setLayout(self.layout)

    def index_dataset(self):
        print("--- Indexing Dataset... ---")
        json_files = glob.glob(os.path.join(self.data_dir, "**", "*.json"), recursive=True)
        
        if not json_files:
            self.info_label.setText("Error: No JSON files found.")
            return

        valid_images_count = 0
        
        for j_path in json_files:
            try:
                with open(j_path, 'r') as f:
                    data = json.load(f)
                
                objects = []
                if isinstance(data, dict):
                    objects = data.get('objects', []) or data.get('shapes', [])
                elif isinstance(data, list):
                    objects = data

                found_classes_in_file = set()
                for obj in objects:
                    name = obj.get('classTitle') or obj.get('label') or obj.get('name')
                    if name:
                        found_classes_in_file.add(name.lower().strip())

                if not found_classes_in_file:
                    continue

                # Path Linking Strategy
                base_name = j_path.replace('.json', '')
                if os.path.exists(base_name):
                    img_path = base_name
                else:
                    parts = base_name.split(os.sep)
                    if 'ann' in parts:
                        possible_img_path = base_name.replace(f'{os.sep}ann{os.sep}', f'{os.sep}img{os.sep}')
                        if os.path.exists(possible_img_path):
                            img_path = possible_img_path
                        else:
                            continue
                    else:
                        continue

                for cls in found_classes_in_file:
                    self.dataset_index[cls].append(img_path)
                    self.all_found_classes[cls] += 1
                
                valid_images_count += 1

            except Exception:
                continue

        self.info_label.setText(f"Indexed {valid_images_count} images successfully.")
        
        self.class_list_widget.clear()
        sorted_classes = sorted(self.all_found_classes.items(), key=lambda x: x[1], reverse=True)
        for cls, count in sorted_classes:
            self.class_list_widget.addItem(f"{cls} ({count} images)")
            
        print(f"Index complete. Found classes: {list(self.all_found_classes.keys())}")

    def on_list_item_clicked(self, item):
        text = item.text()
        fruit_name = text.split(' (')[0]
        self.edit.setText(fruit_name)
        self.search_images()

    def search_images(self):
        query = self.edit.text().lower().strip()
        if not query:
            return

        self.filtered_files = []
        for cls_name, files in self.dataset_index.items():
            if query in cls_name:
                self.filtered_files.extend(files)
        
        self.filtered_files = sorted(list(set(self.filtered_files)))

        if not self.filtered_files:
            QMessageBox.warning(self, "No Results", f"No images found for '{query}'")
            self.image_idx_label.setText("0 images found")
            return

        QMessageBox.information(self, "Found", f"Found {len(self.filtered_files)} images containing '{query}'.")
        
        # Reset slider
        self.slider.setRange(1, len(self.filtered_files))
        self.slider.setValue(1)
        self.slider.setEnabled(True)
        
        # Show montage in Dialog
        self.show_montage(self.filtered_files[:15], query)
        
        # Process first image
        self.update_image_display(1)

    def show_montage(self, files, pattern):
        """Creates a dialog box with the montage grid."""
        images = []
        for f in files:
            img = cv2.imread(f)
            if img is not None:
                # Resize for memory efficiency
                img = cv2.resize(img, (200, 200))
                images.append(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        
        if not images:
            return

        # Initialize and show the custom dialog
        self.montage_window = MontageDialog(images, pattern, self)
        self.montage_window.show()

    def update_image_display(self, idx):
        i = idx - 1
        if i < 0 or i >= len(self.filtered_files):
            return

        filepath = self.filtered_files[i]
        self.image_idx_label.setText(f"Image {idx} / {len(self.filtered_files)}")

        img = cv2.imread(filepath)
        if img is None:
            return
            
        h, w = img.shape[:2]
        if h > 800 or w > 800:
            img = cv2.resize(img, (800, 800), interpolation=cv2.INTER_AREA)

        try:
            # We create a counter here. For production, instantiate once in __init__
            counter = YOLOv5ObjectCounter() 
            count = counter.count_objects(img)
            density = counter.density_map(img)
            
            overlay = self.create_overlay(img, density, count)
            
            plt.figure("MainViewer")
            plt.clf()
            plt.imshow(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
            plt.title(f"File: {os.path.basename(filepath)}\nCount: {count:.0f}")
            plt.axis("off")
            plt.draw()
            plt.pause(0.001)
            
        except Exception as e:
            print(f"Error processing image: {e}")

    def create_overlay(self, image, density_map, count):
        norm_map = cv2.normalize(density_map, None, 0, 255, cv2.NORM_MINMAX).astype("uint8")
        heatmap = cv2.applyColorMap(norm_map, cv2.COLORMAP_JET)
        
        alpha = 0.5
        overlay = cv2.addWeighted(image, 1 - alpha, heatmap, alpha, 0)
        
        text = f"Count: {count:.0f}"
        cv2.putText(overlay, text, (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 
                    1.5, (255, 255, 255), 3)
        return overlay

def main():
    current_dir = os.getcwd()
    data_dir = os.path.join(current_dir, "FruitDetectionDataset")
    
    if not os.path.isdir(data_dir):
        print(f"Error: Dataset not found at {data_dir}")
        sys.exit(1)

    app = QApplication(sys.argv)
    viewer = FruitSearchApp(data_dir)
    viewer.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
```

    --- Indexing Dataset... ---
    Index complete. Found classes: ['wheat', 'cherry', 'apple', 'strawberry', 'blueberry', 'kiwi', 'mango', 'capsicum', 'avocado', 'rockmelon', 'orange']


    qt.qpa.window: Window position QRect(34,-50 1000x800) outside any known screen, using primary screen



    
![png](output_5_2.png)
    


    qt.qpa.window: Window position QRect(34,-50 1000x800) outside any known screen, using primary screen



    
![png](output_5_4.png)
    



    An exception has occurred, use %tb to see the full traceback.


    SystemExit: 0



    /opt/anaconda3/lib/python3.12/site-packages/IPython/core/interactiveshell.py:3585: UserWarning: To exit: use 'exit', 'quit', or Ctrl-D.
      warn("To exit: use 'exit', 'quit', or Ctrl-D.", stacklevel=1)



```python
import os
import sys
import glob
import json
import re
import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from collections import defaultdict, Counter

from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QMessageBox, QSlider, QVBoxLayout, QListWidget, QDialog
)
from PyQt5.QtCore import Qt

from ultralytics import YOLO
import logging

# ---------------------------
# 1. Silence Logs
# ---------------------------
logging.getLogger("ultralytics").setLevel(logging.CRITICAL)

# ---------------------------
# 2. YOLO Counter Class
# ---------------------------
class YOLOv5ObjectCounter:
    def __init__(self, model_path="yolov5s.pt", device="mps"):
        # Auto-download YOLOv5s if not present
        self.model = YOLO(model_path)
        self.model.to(device)
        self.device = device

    def _run(self, image_bgr):
        img_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        results = self.model(
            img_rgb,
            conf=0.1,        
            iou=0.5,
            imgsz=640,
            max_det=300,
            agnostic_nms=True,
            device=self.device,
            verbose=False    
        )
        return results[0]

    def count_objects(self, image_bgr):
        r = self._run(image_bgr)
        return float(len(r.boxes))

    def density_map(self, image_bgr):
        h, w = image_bgr.shape[:2]
        heat = np.zeros((h, w), dtype=np.float32)

        r = self._run(image_bgr)
        if r.boxes is None or len(r.boxes) == 0:
            return heat

        boxes = r.boxes.xyxy.cpu().numpy()
        for x1, y1, x2, y2 in boxes:
            x1, y1, x2, y2 = map(int, [x1, y1, x2, y2])
            x1 = max(0, min(w - 1, x1))
            x2 = max(0, min(w, x2))
            y1 = max(0, min(h - 1, y1))
            y2 = max(0, min(h, y2))
            heat[y1:y2, x1:x2] += 1.0

        if heat.max() > 0:
            heat /= heat.max()
        return heat.astype(np.float32)

# ---------------------------
# 3. Custom Dialog for Montage
# ---------------------------
class MontageDialog(QDialog):
    def __init__(self, images, query, total_count, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Montage Results for '{query}'")
        self.resize(1000, 850) 
        
        # Layout
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # --- NEW: Info Label for Count ---
        info_text = f"Total Found: {total_count} images for '{query}'\n(Displaying preview of top {len(images)})"
        self.count_label = QLabel(info_text)
        self.count_label.setAlignment(Qt.AlignCenter)
        # Make it look nice and bold
        self.count_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #333; margin: 10px;")
        layout.addWidget(self.count_label)
        
        # Matplotlib Figure and Canvas
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)
        
        # Plotting
        self.plot_images(images)

    def plot_images(self, images):
        self.figure.clear()
        
        n = len(images)
        if n == 0:
            return

        # Calculate grid (5 columns fixed)
        cols = 5
        rows = int(np.ceil(n / cols))
        
        for i, img in enumerate(images):
            # Add subplot
            ax = self.figure.add_subplot(rows, cols, i+1)
            ax.imshow(img)
            ax.axis('off')
        
        self.figure.tight_layout()
        self.canvas.draw()

# ---------------------------
# 4. Main GUI Application
# ---------------------------
class FruitSearchApp(QWidget):
    def __init__(self, data_dir):
        super().__init__()
        self.data_dir = data_dir
        
        self.dataset_index = defaultdict(list)
        self.all_found_classes = Counter()
        
        self.filtered_files = []
        self.montage_window = None
        
        self.init_ui()
        self.index_dataset()

    def init_ui(self):
        self.setWindowTitle("Fruit Search & Count (JSON Linked)")
        self.setGeometry(100, 100, 600, 600)

        self.layout = QVBoxLayout()
        
        self.info_label = QLabel("Initializing dataset... please wait.", self)
        self.layout.addWidget(self.info_label)

        self.search_label = QLabel('Enter fruit name (e.g., "avocado", "orange"):', self)
        self.layout.addWidget(self.search_label)

        self.edit = QLineEdit(self)
        self.layout.addWidget(self.edit)

        self.button = QPushButton("Search", self)
        self.button.clicked.connect(self.search_images)
        self.layout.addWidget(self.button)

        self.list_label = QLabel("Available Classes (Double-click to search):", self)
        self.layout.addWidget(self.list_label)
        
        self.class_list_widget = QListWidget(self)
        self.class_list_widget.itemDoubleClicked.connect(self.on_list_item_clicked)
        self.layout.addWidget(self.class_list_widget)

        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.valueChanged.connect(self.update_image_display)
        self.slider.setMinimum(1)
        self.slider.setEnabled(False)
        self.layout.addWidget(self.slider)

        self.image_idx_label = QLabel("0 images found", self)
        self.layout.addWidget(self.image_idx_label)

        self.setLayout(self.layout)

    def index_dataset(self):
        print("--- Indexing Dataset... ---")
        json_files = glob.glob(os.path.join(self.data_dir, "**", "*.json"), recursive=True)
        
        if not json_files:
            self.info_label.setText("Error: No JSON files found.")
            return

        valid_images_count = 0
        
        for j_path in json_files:
            try:
                with open(j_path, 'r') as f:
                    data = json.load(f)
                
                objects = []
                if isinstance(data, dict):
                    objects = data.get('objects', []) or data.get('shapes', [])
                elif isinstance(data, list):
                    objects = data

                found_classes_in_file = set()
                for obj in objects:
                    # Look for 'classTitle' first as per your dataset
                    name = obj.get('classTitle') or obj.get('label') or obj.get('name')
                    if name:
                        found_classes_in_file.add(name.lower().strip())

                if not found_classes_in_file:
                    continue

                # Path Linking Strategy
                base_name = j_path.replace('.json', '')
                if os.path.exists(base_name):
                    img_path = base_name
                else:
                    parts = base_name.split(os.sep)
                    if 'ann' in parts:
                        possible_img_path = base_name.replace(f'{os.sep}ann{os.sep}', f'{os.sep}img{os.sep}')
                        if os.path.exists(possible_img_path):
                            img_path = possible_img_path
                        else:
                            continue
                    else:
                        continue

                for cls in found_classes_in_file:
                    self.dataset_index[cls].append(img_path)
                    self.all_found_classes[cls] += 1
                
                valid_images_count += 1

            except Exception:
                continue

        self.info_label.setText(f"Indexed {valid_images_count} images successfully.")
        
        self.class_list_widget.clear()
        sorted_classes = sorted(self.all_found_classes.items(), key=lambda x: x[1], reverse=True)
        for cls, count in sorted_classes:
            self.class_list_widget.addItem(f"{cls} ({count} images)")
            
        print(f"Index complete. Found classes: {list(self.all_found_classes.keys())}")

    def on_list_item_clicked(self, item):
        text = item.text()
        fruit_name = text.split(' (')[0]
        self.edit.setText(fruit_name)
        self.search_images()

    def search_images(self):
        query = self.edit.text().lower().strip()
        if not query:
            return

        self.filtered_files = []
        for cls_name, files in self.dataset_index.items():
            if query in cls_name:
                self.filtered_files.extend(files)
        
        self.filtered_files = sorted(list(set(self
```


      Cell In[2], line 259
        self.filtered_files = sorted(list(set(self
                                                  ^
    SyntaxError: incomplete input




```python
import os
import sys
import glob
import json
import re
import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from collections import defaultdict, Counter

from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QMessageBox, QSlider, QVBoxLayout, QListWidget, QDialog
)
from PyQt5.QtCore import Qt

from ultralytics import YOLO
import logging

# ---------------------------
# 1. Silence Logs
# ---------------------------
logging.getLogger("ultralytics").setLevel(logging.CRITICAL)

# ---------------------------
# 2. YOLO Counter Class
# ---------------------------
class YOLOv5ObjectCounter:
    def __init__(self, model_path="yolov5s.pt", device="mps"):
        # Auto-download YOLOv5s if not present
        self.model = YOLO(model_path)
        self.model.to(device)
        self.device = device

    def _run(self, image_bgr):
        img_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        results = self.model(
            img_rgb,
            conf=0.1,        
            iou=0.5,
            imgsz=640,
            max_det=300,
            agnostic_nms=True,
            device=self.device,
            verbose=False    
        )
        return results[0]

    def count_objects(self, image_bgr):
        r = self._run(image_bgr)
        return float(len(r.boxes))

    def density_map(self, image_bgr):
        h, w = image_bgr.shape[:2]
        heat = np.zeros((h, w), dtype=np.float32)

        r = self._run(image_bgr)
        if r.boxes is None or len(r.boxes) == 0:
            return heat

        boxes = r.boxes.xyxy.cpu().numpy()
        for x1, y1, x2, y2 in boxes:
            x1, y1, x2, y2 = map(int, [x1, y1, x2, y2])
            x1 = max(0, min(w - 1, x1))
            x2 = max(0, min(w, x2))
            y1 = max(0, min(h - 1, y1))
            y2 = max(0, min(h, y2))
            heat[y1:y2, x1:x2] += 1.0

        if heat.max() > 0:
            heat /= heat.max()
        return heat.astype(np.float32)

# ---------------------------
# 3. Custom Dialog for Montage
# ---------------------------
class MontageDialog(QDialog):
    def __init__(self, images, query, total_count, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Montage Results for '{query}'")
        self.resize(1000, 850) 
        
        # Layout
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # --- NEW: Info Label for Count ---
        info_text = f"Total Found: {total_count} images for '{query}'\n(Displaying preview of top {len(images)})"
        self.count_label = QLabel(info_text)
        self.count_label.setAlignment(Qt.AlignCenter)
        # Make it look nice and bold
        self.count_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #333; margin: 10px;")
        layout.addWidget(self.count_label)
        
        # Matplotlib Figure and Canvas
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)
        
        # Plotting
        self.plot_images(images)

    def plot_images(self, images):
        self.figure.clear()
        
        n = len(images)
        if n == 0:
            return

        # Calculate grid (5 columns fixed)
        cols = 5
        rows = int(np.ceil(n / cols))
        
        for i, img in enumerate(images):
            # Add subplot
            ax = self.figure.add_subplot(rows, cols, i+1)
            ax.imshow(img)
            ax.axis('off')
        
        self.figure.tight_layout()
        self.canvas.draw()

# ---------------------------
# 4. Main GUI Application
# ---------------------------
class FruitSearchApp(QWidget):
    def __init__(self, data_dir):
        super().__init__()
        self.data_dir = data_dir
        
        self.dataset_index = defaultdict(list)
        self.all_found_classes = Counter()
        
        self.filtered_files = []
        self.montage_window = None
        
        self.init_ui()
        self.index_dataset()

    def init_ui(self):
        self.setWindowTitle("Fruit Search & Count (JSON Linked)")
        self.setGeometry(100, 100, 600, 600)

        self.layout = QVBoxLayout()
        
        self.info_label = QLabel("Initializing dataset... please wait.", self)
        self.layout.addWidget(self.info_label)

        self.search_label = QLabel('Enter fruit name (e.g., "avocado", "orange"):', self)
        self.layout.addWidget(self.search_label)

        self.edit = QLineEdit(self)
        self.layout.addWidget(self.edit)

        self.button = QPushButton("Search", self)
        self.button.clicked.connect(self.search_images)
        self.layout.addWidget(self.button)

        self.list_label = QLabel("Available Classes (Double-click to search):", self)
        self.layout.addWidget(self.list_label)
        
        self.class_list_widget = QListWidget(self)
        self.class_list_widget.itemDoubleClicked.connect(self.on_list_item_clicked)
        self.layout.addWidget(self.class_list_widget)

        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.valueChanged.connect(self.update_image_display)
        self.slider.setMinimum(1)
        self.slider.setEnabled(False)
        self.layout.addWidget(self.slider)

        self.image_idx_label = QLabel("0 images found", self)
        self.layout.addWidget(self.image_idx_label)

        self.setLayout(self.layout)

    def index_dataset(self):
        print("--- Indexing Dataset... ---")
        json_files = glob.glob(os.path.join(self.data_dir, "**", "*.json"), recursive=True)
        
        if not json_files:
            self.info_label.setText("Error: No JSON files found.")
            return

        valid_images_count = 0
        
        for j_path in json_files:
            try:
                with open(j_path, 'r') as f:
                    data = json.load(f)
                
                objects = []
                if isinstance(data, dict):
                    objects = data.get('objects', []) or data.get('shapes', [])
                elif isinstance(data, list):
                    objects = data

                found_classes_in_file = set()
                for obj in objects:
                    # Look for 'classTitle' first as per your dataset
                    name = obj.get('classTitle') or obj.get('label') or obj.get('name')
                    if name:
                        found_classes_in_file.add(name.lower().strip())

                if not found_classes_in_file:
                    continue

                # Path Linking Strategy
                base_name = j_path.replace('.json', '')
                if os.path.exists(base_name):
                    img_path = base_name
                else:
                    parts = base_name.split(os.sep)
                    if 'ann' in parts:
                        possible_img_path = base_name.replace(f'{os.sep}ann{os.sep}', f'{os.sep}img{os.sep}')
                        if os.path.exists(possible_img_path):
                            img_path = possible_img_path
                        else:
                            continue
                    else:
                        continue

                for cls in found_classes_in_file:
                    self.dataset_index[cls].append(img_path)
                    self.all_found_classes[cls] += 1
                
                valid_images_count += 1

            except Exception:
                continue

        self.info_label.setText(f"Indexed {valid_images_count} images successfully.")
        
        self.class_list_widget.clear()
        sorted_classes = sorted(self.all_found_classes.items(), key=lambda x: x[1], reverse=True)
        for cls, count in sorted_classes:
            self.class_list_widget.addItem(f"{cls} ({count} images)")
            
        print(f"Index complete. Found classes: {list(self.all_found_classes.keys())}")

    def on_list_item_clicked(self, item):
        text = item.text()
        fruit_name = text.split(' (')[0]
        self.edit.setText(fruit_name)
        self.search_images()

    def search_images(self):
        query = self.edit.text().lower().strip()
        if not query:
            return

        self.filtered_files = []
        for cls_name, files in self.dataset_index.items():
            if query in cls_name:
                self.filtered_files.extend(files)
        
        self.filtered_files = sorted(list(set(self.filtered_files)))

        if not self.filtered_files:
            QMessageBox.warning(self, "No Results", f"No images found for '{query}'")
            self.image_idx_label.setText("0 images found")
            return

        QMessageBox.information(self, "Found", f"Found {len(self.filtered_files)} images containing '{query}'.")
        
        # Reset slider
        self.slider.setRange(1, len(self.filtered_files))
        self.slider.setValue(1)
        self.slider.setEnabled(True)
        
        # Show montage in Dialog (Passing total count now)
        self.show_montage(self.filtered_files[:15], query, len(self.filtered_files))
        
        # Process first image
        self.update_image_display(1)

    def show_montage(self, files, pattern, total_count):
        """Creates a dialog box with the montage grid."""
        images = []
        for f in files:
            img = cv2.imread(f)
            if img is not None:
                img = cv2.resize(img, (200, 200))
                images.append(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        
        if not images:
            return

        # Initialize and show the custom dialog, passing total_count
        self.montage_window = MontageDialog(images, pattern, total_count, self)
        self.montage_window.show()

    def update_image_display(self, idx):
        i = idx - 1
        if i < 0 or i >= len(self.filtered_files):
            return

        filepath = self.filtered_files[i]
        self.image_idx_label.setText(f"Image {idx} / {len(self.filtered_files)}")

        img = cv2.imread(filepath)
        if img is None:
            return
            
        h, w = img.shape[:2]
        if h > 800 or w > 800:
            img = cv2.resize(img, (800, 800), interpolation=cv2.INTER_AREA)

        try:
            counter = YOLOv5ObjectCounter() 
            count = counter.count_objects(img)
            density = counter.density_map(img)
            
            overlay = self.create_overlay(img, density, count)
            
            plt.figure("MainViewer")
            plt.clf()
            plt.imshow(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
            plt.title(f"File: {os.path.basename(filepath)}\nCount: {count:.0f}")
            plt.axis("off")
            plt.draw()
            plt.pause(0.001)
            
        except Exception as e:
            print(f"Error processing image: {e}")

    def create_overlay(self, image, density_map, count):
        norm_map = cv2.normalize(density_map, None, 0, 255, cv2.NORM_MINMAX).astype("uint8")
        heatmap = cv2.applyColorMap(norm_map, cv2.COLORMAP_JET)
        
        alpha = 0.5
        overlay = cv2.addWeighted(image, 1 - alpha, heatmap, alpha, 0)
        
        text = f"Count: {count:.0f}"
        cv2.putText(overlay, text, (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 
                    1.5, (255, 255, 255), 3)
        return overlay

def main():
    current_dir = os.getcwd()
    data_dir = os.path.join(current_dir, "FruitDetectionDataset")
    
    if not os.path.isdir(data_dir):
        print(f"Error: Dataset not found at {data_dir}")
        sys.exit(1)

    app = QApplication(sys.argv)
    viewer = FruitSearchApp(data_dir)
    viewer.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
```

    --- Indexing Dataset... ---
    Index complete. Found classes: ['wheat', 'cherry', 'apple', 'strawberry', 'blueberry', 'kiwi', 'mango', 'capsicum', 'avocado', 'rockmelon', 'orange']


    qt.qpa.window: Window position QRect(34,-25 1000x850) outside any known screen, using primary screen



    
![png](output_7_2.png)
    



    
![png](output_7_3.png)
    



    
![png](output_7_4.png)
    



    
![png](output_7_5.png)
    



    
![png](output_7_6.png)
    



    
![png](output_7_7.png)
    



    
![png](output_7_8.png)
    



    
![png](output_7_9.png)
    


    qt.qpa.window: Window position QRect(34,-25 1000x850) outside any known screen, using primary screen



    
![png](output_7_11.png)
    



    
![png](output_7_12.png)
    



    
![png](output_7_13.png)
    



    
![png](output_7_14.png)
    



    
![png](output_7_15.png)
    



```python

```
